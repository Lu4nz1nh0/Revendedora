# Revendedora
Projeto dos guri !!!
